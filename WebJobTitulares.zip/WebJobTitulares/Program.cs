﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebJobTitulares.Models;
using WebJobTitulares.Repositories;

namespace WebJobTitulares
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pulse ENTER para iniciar");
            Console.ReadLine();
            RepositoryRss reporss = new RepositoryRss();
            List<Noticia> noticias = reporss.GetNoticiasRss();
            foreach (Noticia not in noticias)
            {
                Console.WriteLine(not.Titular);
            }
            RepositoryBbdd repobbdd = new RepositoryBbdd();
            repobbdd.ActualizarNoticias(noticias);
            Console.WriteLine("Noticias actualizadas en BBDD");
            Console.WriteLine("Pulse para finalizar");
            Console.ReadLine();
        }
    }
}
