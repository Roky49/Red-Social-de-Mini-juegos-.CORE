﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WebJobTitulares.Models;

namespace WebJobTitulares.Repositories
{
    public class RepositoryRss
    {
        public List<Noticia> GetNoticiasRss()
        {
            String url = "https://www.gamingdays40.com/category/torneos/feed/";
            //XNamespace ns = "http://purl.org/rss/1.0/";
            XDocument docxml = XDocument.Load(url);
            var consulta = from datos in docxml.Descendants("item")
                           select new Noticia
                           {
 Titular = datos.Element("title").Value ,
Enlace = datos.Element( "link").Value,
Descripcion = datos.Element("description").Value
                           };
            return consulta.ToList();
        }
    }
}
